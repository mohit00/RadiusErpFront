import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-toggle',
  templateUrl: './basic-toggle.component.html',
  styleUrls: ['./basic-toggle.component.scss']
})
export class BasicToggleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
