import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multi-row-toolbar',
  templateUrl: './multi-row-toolbar.component.html',
  styleUrls: ['./multi-row-toolbar.component.scss']
})
export class MultiRowToolbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
