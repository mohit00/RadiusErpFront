import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-tooltip',
  templateUrl: './basic-tooltip.component.html',
  styleUrls: ['./basic-tooltip.component.scss']
})
export class BasicTooltipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
