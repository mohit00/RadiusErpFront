import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-tab-group',
  templateUrl: './custom-tab-group.component.html',
  styleUrls: ['./custom-tab-group.component.scss']
})
export class CustomTabGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
