import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indeterminate-bar',
  templateUrl: './indeterminate-bar.component.html',
  styleUrls: ['./indeterminate-bar.component.scss']
})
export class IndeterminateBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
