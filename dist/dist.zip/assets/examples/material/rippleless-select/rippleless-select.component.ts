import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rippleless-select',
  templateUrl: './rippleless-select.component.html',
  styleUrls: ['./rippleless-select.component.scss']
})
export class RipplelessSelectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
