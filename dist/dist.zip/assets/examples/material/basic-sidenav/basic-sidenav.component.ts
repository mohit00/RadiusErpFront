import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-sidenav',
  templateUrl: './basic-sidenav.component.html',
  styleUrls: ['./basic-sidenav.component.scss']
})
export class BasicSidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
