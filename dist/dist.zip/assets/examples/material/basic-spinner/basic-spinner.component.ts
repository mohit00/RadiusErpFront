import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-spinner',
  templateUrl: './basic-spinner.component.html',
  styleUrls: ['./basic-spinner.component.scss']
})
export class BasicSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
