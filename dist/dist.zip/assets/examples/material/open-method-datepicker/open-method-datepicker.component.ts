import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-method-datepicker',
  templateUrl: './open-method-datepicker.component.html',
  styleUrls: ['./open-method-datepicker.component.scss']
})
export class OpenMethodDatepickerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
