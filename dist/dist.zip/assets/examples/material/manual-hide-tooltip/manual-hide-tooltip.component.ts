import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manual-hide-tooltip',
  templateUrl: './manual-hide-tooltip.component.html',
  styleUrls: ['./manual-hide-tooltip.component.scss']
})
export class ManualHideTooltipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
