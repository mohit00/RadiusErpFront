import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scrollable-dialog-overview',
  templateUrl: './scrollable-dialog-overview.component.html',
  styleUrls: ['./scrollable-dialog-overview.component.scss']
})
export class ScrollableDialogOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
