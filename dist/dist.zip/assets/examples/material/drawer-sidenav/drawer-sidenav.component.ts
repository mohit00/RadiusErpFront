import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drawer-sidenav',
  templateUrl: './drawer-sidenav.component.html',
  styleUrls: ['./drawer-sidenav.component.scss']
})
export class DrawerSidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
